const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

window.addEventListener("load",()=>setTimeout(()=>$("#loader").classList.add("hide"),500));

/* Starfield */
const canvas=$("#spaceCanvas"), ctx=canvas.getContext("2d");
let stars=[], W,H,dpr=1, mouse={x:.5,y:.5};
function resizeStars(){
  dpr=Math.min(devicePixelRatio||1,2); W=innerWidth; H=innerHeight;
  canvas.width=W*dpr; canvas.height=H*dpr; canvas.style.width=W+"px"; canvas.style.height=H+"px";
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const count=Math.min(180,Math.floor(W*H/7000));
  stars=Array.from({length:count},()=>({x:Math.random()*W,y:Math.random()*H,z:Math.random(),r:Math.random()*1.5+.2,v:Math.random()*.25+.05}));
}
function drawStars(){
  ctx.clearRect(0,0,W,H);
  for(const s of stars){
    s.y+=s.v;if(s.y>H)s.y=-2;
    const dx=(mouse.x-.5)*s.z*15, dy=(mouse.y-.5)*s.z*15;
    ctx.beginPath();ctx.arc(s.x+dx,s.y+dy,s.r*s.z+.25,0,Math.PI*2);
    ctx.fillStyle=`rgba(190,170,255,${.2+s.z*.65})`;ctx.fill();
  }
  requestAnimationFrame(drawStars);
}
addEventListener("resize",resizeStars); addEventListener("pointermove",e=>{mouse.x=e.clientX/W;mouse.y=e.clientY/H});
resizeStars();drawStars();

/* Reveal animations */
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");io.unobserve(e.target)}}),{threshold:.12});
$$(".reveal").forEach(x=>io.observe(x));

/* Topic modal */
const topicData={
 astronomy:["ASTRONOMY","Astronomy explores objects and phenomena beyond Earth: planets, stars, galaxies, nebulae and the structure of the universe.","Light from distant objects can take millions or even billions of years to reach us, so telescopes can act like time machines."],
 physics:["PHYSICS","Physics studies matter, energy, motion, forces and the fundamental rules that describe nature.","The same physical laws that describe motion on Earth also help scientists model the motion of planets and spacecraft."],
 chemistry:["CHEMISTRY","Chemistry studies matter and the transformations between substances. Atoms combine into molecules through different kinds of chemical bonding.","The periodic table is organized by atomic number — the number of protons in an atom's nucleus."],
 biology:["BIOLOGY","Biology studies living systems, from molecules and cells to organisms and ecosystems.","DNA stores biological instructions using four chemical bases: A, T, C and G."],
 ai:["ARTIFICIAL INTELLIGENCE","Modern AI systems can learn statistical patterns from data and use those learned patterns for tasks such as prediction, classification and generation.","Neural networks are inspired loosely by biological neurons, but they are mathematical models rather than digital copies of the brain."]
};
$$(".learn-btn").forEach(b=>b.addEventListener("click",e=>{
  const d=topicData[e.currentTarget.closest(".science-card").dataset.topic];
  $("#modalLabel").textContent=d[0];$("#modalTitle").textContent=d[0].replace("ARTIFICIAL INTELLIGENCE","Artificial Intelligence").replace("ASTRONOMY","Astronomy").replace("PHYSICS","Physics").replace("CHEMISTRY","Chemistry").replace("BIOLOGY","Biology");
  $("#modalText").textContent=d[1];$("#modalFact").textContent="✦ "+d[2];$("#topicModal").classList.add("open");$("#topicModal").setAttribute("aria-hidden","false");document.body.classList.add("modal-open");
}));
function closeModal(){$("#topicModal").classList.remove("open");$("#topicModal").setAttribute("aria-hidden","true");document.body.classList.remove("modal-open")}
$("#modalClose").onclick=closeModal;$("#topicModal").addEventListener("click",e=>{if(e.target===$("#topicModal"))closeModal()});addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

/* Facts */
const facts=[
"A day on Venus is longer than a year on Venus.",
"Neutron stars are so dense that a tiny amount of their matter would have an enormous mass.",
"Lightning can heat the surrounding air to temperatures hotter than the surface of the Sun.",
"Your DNA contains an enormous amount of information packed into microscopic structures called chromosomes.",
"Water is one of the few common substances that naturally exists on Earth as a solid, liquid and gas.",
"AI models learn patterns from data; they do not need to be conscious to perform useful tasks."
];
let fi=0;$("#factBtn").onclick=()=>{fi=(fi+1)%facts.length;$("#factText").textContent=facts[fi]};

/* Games */
$$(".game-tab").forEach(tab=>tab.onclick=()=>{
  $$(".game-tab").forEach(t=>t.classList.remove("active"));tab.classList.add("active");
  $$(".game-panel").forEach(p=>p.classList.add("hidden"));$("#game-"+tab.dataset.game).classList.remove("hidden");
});

/* Orbital Run */
const oc=$("#orbitCanvas"), ox=oc.getContext("2d");let ow=0,oh=0,probe={a:0},orbitRunning=false,orbScore=0,keys={};
function resizeOrbit(){const r=oc.getBoundingClientRect();const d=Math.min(devicePixelRatio||1,2);ow=r.width;oh=r.height;oc.width=ow*d;oc.height=oh*d;ox.setTransform(d,0,0,d,0,0)}
function resetOrbit(){probe.a=0;orbScore=0;$("#orbitScore").textContent="0 / 3";orbitRunning=true}
function orbitLoop(t){
  if(!ow){resizeOrbit()}
  ox.clearRect(0,0,ow,oh);const cx=ow/2,cy=oh/2,R=Math.min(ow,oh)*.31;
  const grd=ox.createRadialGradient(cx,cy,5,cx,cy,70);grd.addColorStop(0,"#e4d8ff");grd.addColorStop(.18,"#9b6cff");grd.addColorStop(1,"rgba(100,50,230,0)");
  ox.fillStyle=grd;ox.beginPath();ox.arc(cx,cy,80,0,7);ox.fill();
  ox.strokeStyle="rgba(155,108,255,.25)";ox.lineWidth=1;ox.beginPath();ox.arc(cx,cy,R,0,7);ox.stroke();
  if(orbitRunning){
    if(keys.left)probe.a-=.035;if(keys.right)probe.a+=.035;
    probe.a+=.006;
  }
  const px=cx+Math.cos(probe.a)*R,py=cy+Math.sin(probe.a)*R*.65;
  ox.fillStyle="#d8c6ff";ox.shadowBlur=18;ox.shadowColor="#9b6cff";ox.beginPath();ox.arc(px,py,6,0,7);ox.fill();ox.shadowBlur=0;
  for(let i=0;i<3;i++){const a=1.5+i*2.1;const nx=cx+Math.cos(a)*R,ny=cy+Math.sin(a)*R*.65;ox.fillStyle="#5ab8ff";ox.beginPath();ox.arc(nx,ny,4,0,7);ox.fill()}
  requestAnimationFrame(orbitLoop);
}
addEventListener("resize",resizeOrbit);
$$("[data-start='orbit']").forEach(b=>b.onclick=resetOrbit);
addEventListener("keydown",e=>{if(e.key==="ArrowLeft")keys.left=true;if(e.key==="ArrowRight")keys.right=true});
addEventListener("keyup",e=>{if(e.key==="ArrowLeft")keys.left=false;if(e.key==="ArrowRight")keys.right=false});
$$(".mobile-controls button").forEach(b=>{
  const k=b.dataset.key;b.addEventListener("pointerdown",()=>keys[k]=true);b.addEventListener("pointerup",()=>keys[k]=false);b.addEventListener("pointerleave",()=>keys[k]=false);
});
resizeOrbit();orbitLoop();

/* Atom Builder */
let atomScore=0;
function targetCarbon(){ $("#atomTarget").textContent="Target: Carbon — C (6 protons, 6 neutrons, 6 electrons)"; }
targetCarbon();
$("#atomCheck").onclick=()=>{
  const p=+$("#protons").value,n=+$("#neutrons").value,e=+$("#electrons").value;
  $("#pCount").textContent=p;$("#nCount").textContent=n;
  const ok=p===6&&n===6&&e===6;
  if(ok){atomScore++;$("#atomScore").textContent=atomScore;$("#atomResult").textContent="✓ Correct! 6 protons identifies carbon. 6 electrons makes it neutral."; }
  else $("#atomResult").textContent="Not quite — Carbon has 6 protons. A neutral carbon atom has 6 electrons; this challenge uses 6 neutrons.";
};

/* Reaction Lab */
let reactionScore=0;
const reactions=[
  {eq:"H₂ + O₂ → ?",a:"H2O",ok:"Correct! Hydrogen and oxygen can form water."},
  {eq:"C + O₂ → ?",a:"CO2",ok:"Correct! Carbon reacting with oxygen can form carbon dioxide."},
  {eq:"Na + Cl → ?",a:"NaCl",ok:"Correct! Sodium and chlorine form sodium chloride."}
];
let ri=0;
function loadReaction(){const r=reactions[ri];$("#reactionEquation").textContent=r.eq;$("#reactionResult").textContent="";$$(".reaction-options button").forEach(b=>b.disabled=false)}
$$(".reaction-options button").forEach(b=>b.onclick=()=>{
  const r=reactions[ri],correct=b.dataset.answer===r.a;
  if(correct){reactionScore++;$("#reactionScore").textContent=reactionScore;$("#reactionResult").textContent="✓ "+r.ok}
  else $("#reactionResult").textContent="Try again — think about which atoms can combine to conserve the elements.";
});
$("#nextReaction").onclick=()=>{ri=(ri+1)%reactions.length;loadReaction()};loadReaction();

/* Gentle hero parallax */
const heroVisual=$("#blackHoleArea");
addEventListener("pointermove",e=>{
  if(innerWidth<800)return;
  const x=(e.clientX/innerWidth-.5),y=(e.clientY/innerHeight-.5);
  heroVisual.style.transform=`translate(${x*8}px,${y*6}px)`;
});
addEventListener("pointerleave",()=>heroVisual.style.transform="");
